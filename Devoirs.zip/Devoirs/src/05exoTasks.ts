"use strict";
import TodoList from "./components/TodoList.js";

// Création d'une todoList
const todoList = new TodoList();

